#!/bin/bash

red=`tput setaf 1`
green=`tput setaf 2`
bold=`tput bold`
reset=`tput sgr0`

export GOOGLE_APPLICATION_CREDENTIALS=~/tf_keys/gcp/terraform_hub_project_x.json
gcloud auth activate-service-account --key-file ~/tf_keys/gcp/terraform_hub_project_x.json

terraform_destroy() {
  terraform init && terraform destroy -auto-approve
  if [ $? -eq 0 ]; then
    echo ""
    echo "${bold}${green}Destroy complete!!!${reset}"
  else
    echo "${bold}${red} Error encountered!!!${reset}"
  fi
}

time terraform_destroy
